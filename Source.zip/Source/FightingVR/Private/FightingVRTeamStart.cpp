// Copyright Epic Games, Inc. All Rights Reserved.

#include "FightingVRTeamStart.h"
#include "FightingVR.h"

AFightingVRTeamStart::AFightingVRTeamStart(const FObjectInitializer& ObjectInitializer) 
	: Super(ObjectInitializer) 
{

}
