// Copyright Epic Games, Inc. All Rights Reserved.

#include "Weapons/FightingVRDamageType.h"
#include "FightingVR.h"

UFightingVRDamageType::UFightingVRDamageType(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
}